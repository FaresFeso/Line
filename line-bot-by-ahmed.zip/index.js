const { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder } = require('discord.js');
require('dotenv').config();

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
    ],
});

let targetChannelIds = [];  // Array to store the target channel IDs
let messageContent = 'Hi';  // Default message content

client.once('ready', async () => {
    console.log(`Logged in as ${client.user.tag}!`);

    const commands = [
        new SlashCommandBuilder()
            .setName('change')
            .setDescription('Change the target room ID')
            .addStringOption(option =>
                option.setName('channelid')
                    .setDescription('The ID of the channel')
                    .setRequired(true)),
        new SlashCommandBuilder()
            .setName('add')
            .setDescription('Add a channel ID to the target list')
            .addStringOption(option =>
                option.setName('channelid')
                    .setDescription('The ID of the channel')
                    .setRequired(true)),
        new SlashCommandBuilder()
            .setName('remove')
            .setDescription('Remove a channel ID from the target list')
            .addStringOption(option =>
                option.setName('channelid')
                    .setDescription('The ID of the channel')
                    .setRequired(true)),
       new SlashCommandBuilder()
           .setName('setline')
           .setDescription('Set the line to be sent')
          .addStringOption(option =>
           option.setName('line')
               .setDescription('The line Link')
                     .setRequired(true)),
    ].map(command => command.toJSON());

    const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

    try {
        console.log('Started refreshing application (/) commands.');

        await rest.put(
            Routes.applicationCommands(client.user.id),
            { body: commands },
        );

        console.log('Successfully reloaded application (/) commands.');
    } catch (error) {
        console.error(error);
    }
});

client.on('messageCreate', message => {
    // Ignore messages from the bot itself
    if (message.author.bot) return;

    // Check if the message was sent in any of the specified channels
    if (targetChannelIds.includes(message.channel.id)) {
        // Respond with the message content in the same channel
        message.channel.send(messageContent);
    }
});

client.on('interactionCreate', async interaction => {
    if (!interaction.isCommand()) return;

    const { commandName, options } = interaction;

    if (commandName === 'change') {
        const channelId = options.getString('channelid');
        targetChannelIds = [channelId];  // Replace the list with the new ID
        await interaction.reply(`Channel ID set to ${channelId}`);
    } else if (commandName === 'add') {
        const channelId = options.getString('channelid');
        if (!targetChannelIds.includes(channelId)) {
            targetChannelIds.push(channelId);  // Add the new ID to the list
            await interaction.reply(`Channel ID ${channelId} added`);
        } else {
            await interaction.reply(`Channel ID ${channelId} is already in the list`);
        }
    } else if (commandName === 'remove') {
        const channelId = options.getString('channelid');
        const index = targetChannelIds.indexOf(channelId);
        if (index !== -1) {
            targetChannelIds.splice(index, 1);  // Remove the channel ID from the list
            await interaction.reply(`Channel ID ${channelId} removed`);
        } else {
            await interaction.reply(`Channel ID ${channelId} is not in the list`);
        }
    } else if (commandName === 'setmessage') {
        const newMessage = options.getString('message');
        messageContent = newMessage;
        await interaction.reply(`Message set to "${newMessage}"`);
    }
});

// Login to Discord with your bot's token
client.login(process.env.DISCORD_TOKEN);
